// Create function addUser()
function addUser() {
  // Get value of user by id player1_name_input and player2_name_input
      document.getElementById("player1_name_input").value;
      document.getElementById("player2_name_input").value;
      
  // Store these values locally
  window.location="game_login.html"
  //Assign "game_page.html" to window.location
}

